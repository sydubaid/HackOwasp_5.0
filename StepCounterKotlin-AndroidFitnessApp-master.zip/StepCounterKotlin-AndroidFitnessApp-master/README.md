# StepCounterKotlinAndroidApp 

. Step counter using background service and upadte main UI and Notification progress with steps, calories burnt and distance covered.<br />
. Check out the video for complete code explanation. 

# Required
.  Android Studio 4.0 or newer required.<br />
.  Physical device required<br />

![learn to code youtube thumbnail ](https://user-images.githubusercontent.com/16830594/91642828-f4459580-ea47-11ea-97f5-ac5427bb40d2.jpg)

# Youtube 
https://www.youtube.com/channel/UCP5dR7E8KZRLuzhdY6zbp0A
