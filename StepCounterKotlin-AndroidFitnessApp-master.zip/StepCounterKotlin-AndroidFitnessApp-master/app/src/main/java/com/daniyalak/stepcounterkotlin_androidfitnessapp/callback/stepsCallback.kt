package com.daniyalak.stepcounterkotlin_androidfitnessapp.callback

interface stepsCallback {

    fun subscribeSteps(steps: Int)
}